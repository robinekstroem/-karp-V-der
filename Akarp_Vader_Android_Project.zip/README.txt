Åkarp Väder – Androidprojekt

Projektet är färdigt för Android Studio/Gradle och bygger en APK.
Appen använder en lokal WebView och hämtar aktuell prognos från Open-Meteo för Åkarp.

Bygg:
  gradle assembleDebug

APK hamnar i:
  app/build/outputs/apk/debug/app-debug.apk

Det finns även en GitHub Actions-workflow i .github/workflows/build.yml.
